package com.capgemini.manytomany;

import java.time.LocalDate;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("Customer");
		EntityManager entityManager=emf.createEntityManager();
		EntityTransaction transaction=entityManager.getTransaction();
		transaction.begin();
		Events java=new Events();
		java.setEventId("101-Java");
		java.setEventName("Java");
		java.setDate(LocalDate.now());
		java.setDate(LocalDate.now());
		Events oracle=new Events();
		oracle.setEventId("456-Oracle");
		oracle.setEventName("Oracle");
		oracle.setDate(LocalDate.now());
		Events dotnet=new Events();
		dotnet.setEventId("789-DotNet");
		dotnet.setEventName("DotNet");
		dotnet.setDate(LocalDate.now());
		Delegates tom=new Delegates(1,"tom");
		tom.getEvents().add(java);
		tom.getEvents().add(oracle);
		Delegates jack=new Delegates(2,"jack");
		jack.getEvents().add(java);
		jack.getEvents().add(oracle);
		jack.getEvents().add(dotnet);
		Delegates smith=new Delegates(3,"smith");
		smith.getEvents().add(java);
		smith.getEvents().add(dotnet);
		entityManager.persist(java);
		entityManager.persist(oracle);
		entityManager.persist(dotnet);
		entityManager.persist(tom);
		entityManager.persist(jack);
		entityManager.persist(smith);
		transaction.commit();
		entityManager.close();
		

	}

}
