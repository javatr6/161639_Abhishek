package org.cap.manytomany;

import java.text.ParseException;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

public class Test {
	public static void main(String[] args) throws ParseException {


		EntityManagerFactory emf = 
				Persistence.createEntityManagerFactory("test");
		EntityManager em = emf.createEntityManager();
		EntityTransaction transaction= em.getTransaction();

		transaction.begin();
		
		Event java=new Event("1234-Java", "Java");
		Event oracle=new Event("1233-oracle", "oracle");
		Event dotnet=new Event("1235-dotnet", "dotnet");
		
		Delgates tom=new Delgates(100, "Tom");
		Delgates tim=new Delgates(101, "Tim");
		Delgates jack=new Delgates(102, "jack");
		Delgates jim=new Delgates(103, "jim");
		
		tom.getEvents().add(dotnet);
		tom.getEvents().add(oracle);
		
		tim.getEvents().add(java);
		
		jack.getEvents().add(java);
		jack.getEvents().add(dotnet);
	
		jim.getEvents().add(oracle);
		jim.getEvents().add(java);
		
		em.persist(tim);
		em.persist(jim);
		em.persist(jack);
		em.persist(tom);
		em.persist(dotnet);
		em.persist(oracle);
		em.persist(java);
		transaction.commit();
		em.close();

	}

}
