package loginPage;


import static org.junit.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import bean.HotelbookingPageBean;
import bean.LoginBean;
import bean.SuccessBean;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class Stepdef {
	private WebDriver driver;
	private HotelbookingPageBean hotelBookingPageBean;
	private LoginBean loginBean;
	@Before
	public void setUp() {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver\\chromedriver.exe");
		driver=new ChromeDriver();
		hotelBookingPageBean=new HotelbookingPageBean(driver);
		loginBean=new LoginBean(driver);
	}

	@Given("^open login page$")
	public void open_login_page() throws Throwable {
		driver.get("file:///D:/myworkabhi/assignment/src/main/WEB-INF/index.html");

		assertEquals("Hotel Booking Application",loginBean.getPageHeading());
	}

	@Given("^username and password$")
	public void username_and_password() throws Throwable {
		loginBean.assignValues("capgemini", "capg1234");
	}

	@When("^login validate details$")
	public void login_validate_details() throws Throwable {
		loginBean.setSignBtn();
	}

	@Then("^redirect to hotelbooking page$")
	public void redirect_to_hotelbooking_page() throws Throwable {
		driver.navigate().to("file:///D:/myworkabhi/assignment/src/main/webapp/pages/hotelbooking.html");
		assertEquals("Hotel Booking Form",hotelBookingPageBean.getPageHeading());
	}

	@Given("^username$")
	public void username() throws Throwable {
		loginBean.assignValues("", "capg1234");
	}

	@When("^login$")
	public void login() throws Throwable {
		loginBean.setSignBtn();
	}

	@Then("^show errormessage$")
	public void show_errormessage() throws Throwable {
		String userErrorMsg=driver.findElement(By.xpath("//*[@id=\"userErrMsg\"]")).getText();
		System.out.println("Msg"+userErrorMsg);
		assertEquals("* Please enter userName.",userErrorMsg);
		Thread.sleep(1000);
	}

	@Given("^password$")
	public void password() throws Throwable {
		loginBean.assignValues("capgemini", "");
	}

	@When("^login clicked$")
	public void login_clicked() throws Throwable {
		loginBean.setSignBtn();
	}

	@Then("^show popup$")
	public void show_popup() throws Throwable {
		String userErrorMsg=driver.findElement(By.xpath("//*[@id=\"pwdErrMsg\"]")).getText();
		System.out.println("Msg"+userErrorMsg);
		assertEquals("* Please enter password.",userErrorMsg);
	}
	@After
	public void tearDown() {
		driver.quit();
	}
}
